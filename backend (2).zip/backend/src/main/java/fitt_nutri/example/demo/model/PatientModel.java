package fitt_nutri.example.demo.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.validator.constraints.br.CPF;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "Paciente")
public class PatientModel {

    public PatientModel(Integer id) {
        this.id = id;
    }


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotBlank(message = "Nome não pode estar vazio")
    @Column(nullable = false)
    private String nome;

    @Email
    @NotBlank(message = "Email não pode estar vazio")
    @Column(nullable = false, unique = true)
    private String email;

    @CPF
    @NotBlank(message = "CPF não pode estar vazio")
    @Column(nullable = false, unique = true)
    private String cpf;

    @Column(nullable = false)
    private String telefone;

    @NotBlank(message = "O campo estado não pode estar vazio")
    @Column(nullable = false)
    private String estado;

    @Column(nullable = false)
    private String cidade;

    @NotBlank(message = "O campo sexo não pode estar vazio")
    @Column(nullable = false)
    private String sexo;

    @NotBlank(message = "O campo etnia não pode estar vazio")
    @Column(nullable = false)
    private String etnia;

    @NotNull(message = "O campo atividade não pode estar vazio")
    @Column(nullable = false)
    private String atividade;

    @Column(name = "motivo_consulta")
    private String motivoConsulta;

    @OneToMany(mappedBy = "paciente", cascade = CascadeType.ALL)
    private List<SchedulingModel> agendamentos = new ArrayList<>();

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private UserModel nutricionista;


    @OneToMany(mappedBy = "paciente", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<DataCircleModel> circunferencias = new ArrayList<>();

    public void addCirc(DataCircleModel m) {
        if (m == null) return;
        if (!circunferencias.contains(m)) {
            circunferencias.add(m);
            m.setPaciente(this);
        }
    }

    public void removeCirc(DataCircleModel m) {
        if (m == null) return;
        if (circunferencias.remove(m)) {
            m.setPaciente(null);
        }
    }
}
